//
//  ViewController.m
//  MultiTouches
//
//  Created by 汪炳央 on 15/3/14.
//  Copyright (c) 2015年 汪炳央. All rights reserved.
//

#import "ViewController.h"
#import "MultiTouchesView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.multiTouchesView = [[MultiTouchesView alloc] initWithFrame:self.view.frame];
    [self.multiTouchesView setBackgroundColor:[UIColor blackColor]];

    [self.view addSubview:self.multiTouchesView];
    [self.view sendSubviewToBack:self.multiTouchesView];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}





@end
