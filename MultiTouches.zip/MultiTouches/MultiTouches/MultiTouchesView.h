//
//  MultiTouchesView.h
//  MultiTouches
//
//  Created by 汪炳央 on 15/3/14.
//  Copyright (c) 2015年 汪炳央. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MultiTouchesView : UIView {

    NSInteger pointNum; //当前触摸的手指个数
}

@property (nonatomic,strong) NSMutableArray *pointArray;
@property (nonatomic,strong) NSMutableArray *pointArray0;
@property (nonatomic,strong) NSMutableArray *pointArray1;
@property (nonatomic,strong) NSMutableArray *pointArray2;
@property (nonatomic,strong) NSMutableArray *pointArray3;
@property (nonatomic,strong) NSMutableArray *pointArray4;

@property (nonatomic,strong) NSMutableArray *lineArray;


@property (nonatomic,strong) NSMutableArray *colorArray;
@property (nonatomic,strong) NSMutableArray *touchID;

@end
