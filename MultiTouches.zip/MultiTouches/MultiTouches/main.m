//
//  main.m
//  MultiTouches
//
//  Created by 汪炳央 on 15/3/14.
//  Copyright (c) 2015年 汪炳央. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
