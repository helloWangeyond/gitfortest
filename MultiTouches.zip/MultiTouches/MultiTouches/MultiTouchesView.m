//
//  MultiTouchesView.m
//  MultiTouches
//
//  Created by 汪炳央 on 15/3/14.
//  Copyright (c) 2015年 汪炳央. All rights reserved.
//

#import "MultiTouchesView.h"

@implementation MultiTouchesView


- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.pointArray0 = [[NSMutableArray alloc] init];
        self.pointArray1 = [[NSMutableArray alloc] init];
        self.pointArray2 = [[NSMutableArray alloc] init];
        self.pointArray3 = [[NSMutableArray alloc] init];
        self.pointArray4 = [[NSMutableArray alloc] init];
        self.pointArray = [NSMutableArray arrayWithObjects:self.pointArray0, self.pointArray1, self.pointArray2, self.pointArray3, self.pointArray4, nil];

        self.lineArray = [[NSMutableArray alloc] init];
        
        //设置touchID和轨迹线的color
        self.colorArray = [NSMutableArray arrayWithObjects:[UIColor greenColor], [UIColor redColor], [UIColor purpleColor], [UIColor cyanColor], [UIColor orangeColor], nil];
        
        //初始化touchID
        self.touchID = [[NSMutableArray alloc] init];
        for (int i = 0; i < 5; i++) {
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, (10 + 10*i), 180, 20)];
            label.font = [UIFont fontWithName:@"Arial" size:10.0f];
            label.textColor = [self.colorArray objectAtIndex:i];
            [self.touchID addObject:label];
            [self addSubview:label];
        }

    }
    return self;
}


- (void)drawRect:(CGRect)rect
{
    //获取当前上下文，
    CGContextRef context=UIGraphicsGetCurrentContext();
    CGContextBeginPath(context);
    CGContextSetLineWidth(context, 1.0f);
    //线条拐角样式，设置为平滑
    CGContextSetLineJoin(context,kCGLineJoinRound);
    //线条开始样式，设置为平滑
    CGContextSetLineCap(context, kCGLineCapRound);
    
    CGContextSetRGBStrokeColor(context, 0.0, 1.0, 0.0, 1);

//    //保存历史轨迹
//    if ([self.lineArray count]>0) {
//        for (int i=0; i<[self.lineArray count]; i++) {
//            NSArray * array=[NSArray
//                             arrayWithArray:[self.lineArray objectAtIndex:i]];
//            
//            if ([array count]>0)
//            {
//                CGContextBeginPath(context);
//                CGPoint startPoint=CGPointFromString([array objectAtIndex:0]);
//                CGContextMoveToPoint(context, startPoint.x, startPoint.y);
//                
//                for (int j=0; j<[array count]-1; j++)
//                {
//                    CGPoint endPoint=CGPointFromString([array objectAtIndex:j+1]);
//                    CGContextAddLineToPoint(context, endPoint.x,endPoint.y);
//                }
//                
//                //保存自己画的
//                CGContextStrokePath(context);
//            }
//        }
//    }
    

    if ([[self.pointArray objectAtIndex:0] count] > 0) {
        
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextBeginPath(context);

        for (int i = 0; i < pointNum; i++) {
            
            //设置当前轨迹线的color
            UIColor *lineColor = [self.colorArray objectAtIndex:i];
            CGContextSetStrokeColorWithColor(context, lineColor.CGColor);
            
            //获取当前触摸手指保存的坐标点
            NSMutableArray *sPointArray = [self.pointArray objectAtIndex:i];
            
            CGPoint startPoint = CGPointFromString([sPointArray objectAtIndex:0]);
            CGContextMoveToPoint (context, startPoint.x, startPoint.y);
            
            for (int j = 0; j < (sPointArray.count - 1); j++) {
                
                CGPoint endPoint = CGPointFromString([sPointArray objectAtIndex:j]);
                CGContextAddLineToPoint (context, endPoint.x, endPoint.y);

            }
            NSLog(@"current point = %d ",i + 1);
            //finish current line
            CGContextStrokePath(context);
        }

    }

}

//手指开始触屏开始
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSSet *allTouches = [event allTouches];    //返回与当前接收者有关的所有的触摸对象
    UITouch *touch = [allTouches anyObject];   //视图中的所有对象
    //获取触摸的手指个数
    pointNum = event.allTouches.count;
    if ([touch tapCount] == 2) {
        [self setNeedsDisplay];
        NSLog(@"double click ...");
    } else {
        [self touchesMoved:touches withEvent:event];
    }
}

//手指移动时候发出
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    for (int i = 0; i < pointNum; i++) {

        NSArray *touches = [event.allTouches allObjects];
        //获取当前触摸手指的坐标CGPoint
        CGPoint sPoint = [[touches objectAtIndex:i] locationInView:self];
        //将CGpoint转换成NSString类
        NSString *NSPoint  = NSStringFromCGPoint(sPoint);
        //取出self.pointArray里用于保存坐标的当前数组
        NSMutableArray *sPointArray = [self.pointArray objectAtIndex:i];
        //保存当前手指的坐标点
        [sPointArray addObject:NSPoint];
    
    }
    
    [self reportCurrentPointLocation];

    [self setNeedsDisplay];
}

//当手指离开屏幕时候
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
//    //保留历史路径
//    NSArray *array=[NSArray arrayWithArray:self.pointArray];
//    [self.lineArray addObject:array];
    
    //重置用于保存坐标点的数组，再次画线时清空上次的轨迹线
    for (int i = 0; i < pointNum; i++) {
        
        [[self.pointArray objectAtIndex:i] removeAllObjects];

        NSLog(@"%d touch end ",i);
    }
    
}

//上报坐标
- (void)reportCurrentPointLocation {
    
    for (int i = 0; i < 5; i++) {
        UILabel *label = [self.touchID objectAtIndex:i];
        label.hidden = YES;
    }
    
    for (int i = 0; i < pointNum; i++) {
        NSMutableArray *sPointArray = [self.pointArray objectAtIndex:i];
        
        CGPoint currentPointLocation = CGPointFromString([sPointArray objectAtIndex:(sPointArray.count - 1)]);
        
        UILabel *label = [self.touchID objectAtIndex:i];
        label.hidden = NO;
        label.text = [NSString stringWithFormat:@"x%d = %.0f , y%d = %.0f",i,currentPointLocation.x, i,currentPointLocation.y];
    }
    
}




/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/






@end
