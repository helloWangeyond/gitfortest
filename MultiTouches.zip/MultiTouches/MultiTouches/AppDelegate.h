//
//  AppDelegate.h
//  MultiTouches
//
//  Created by 汪炳央 on 15/3/14.
//  Copyright (c) 2015年 汪炳央. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

